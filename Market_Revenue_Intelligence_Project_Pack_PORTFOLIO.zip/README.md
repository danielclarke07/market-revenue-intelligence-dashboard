# Market & Revenue Intelligence Dashboard (Excel)

Portfolio-grade Excel workbook that demonstrates KPI design, segmentation, and scenario forecasting using order-level data.

## What to open first
- **Dashboard** (filters + KPIs + trend + region/channel breakdown)
- **Forecast** (Base/Best/Worst scenario selector + break-even + operating profit forecast)
- **Segments** (category performance and drivers)
- **DATA_DICTIONARY** (field definitions)

## What makes this “real”
- The dashboard metrics are built from the order table (no hard-coded totals).
- Every number can be audited back to **Raw_Data → Orders**.
- Forecast assumptions are explicit and switchable (Base/Best/Worst).

## How to demo at BEYA (talk track)
“I built an Excel decision tool that takes order-level data and turns it into KPIs, trend analysis, and a forecast. The dashboard shows what drives revenue and profit by region, channel, and category. Then the forecast tab shows how sensitive operating profit is to traffic, conversion, and AOV, including a break-even point.”

## Replace the dataset (no coding)
1. Open the workbook → **Raw_Data**
2. Paste your data into the Excel Table named **Orders** (keep headers)
3. Return to **Dashboard** — everything updates

## Files
- `Market_Revenue_Intelligence_Dashboard_PORTFOLIO.xlsx`
- `data_raw_orders.csv`
- `EXECUTIVE_SUMMARY.md`

## GitHub
Yes—GitHub is useful here because recruiters can skim the README and download the workbook.
If you add screenshots, include:
- Dashboard (top KPIs + chart)
- Forecast (scenario selector + break-even)

(Use synthetic/public/anonymized data only for public repos.)
